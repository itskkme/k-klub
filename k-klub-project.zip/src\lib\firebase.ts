
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD1eomR3gQvPp8waT8ULbB2rM8zhIhXUDg",
  authDomain: "k-klub-style-hub-v1.firebaseapp.com",
  projectId: "k-klub-style-hub-v1",
  storageBucket: "k-klub-style-hub-v1.firebasestorage.app",
  messagingSenderId: "59814052632",
  appId: "1:59814052632:web:9f58a844e67ed9778e546d"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
