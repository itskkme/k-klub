
import { useEffect, ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const AdminRoute = ({ children }: { children: ReactNode }) => {
    const { user, loading, isAdmin } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (!loading && (!user || !isAdmin)) {
            toast.error("Access denied. Admin privileges required.");
            navigate("/");
        }
    }, [user, loading, isAdmin, navigate]);

    if (loading) {
        return <div>Loading...</div>;
    }

    return user && isAdmin ? <>{children}</> : null;
};

export default AdminRoute;
