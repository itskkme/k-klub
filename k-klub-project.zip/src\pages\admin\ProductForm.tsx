
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { doc, getDoc, setDoc, updateDoc, collection, addDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";
import Navbar from "@/components/layout/Navbar";
import { categories } from "@/data/mockProducts";

const ProductForm = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = !!id;

    const [formData, setFormData] = useState({
        name: "",
        brand: "",
        price: "",
        category: "",
        images: "", // Changed to string for textarea (one URL per line)
        description: "",
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (isEdit && id) {
            const fetchProduct = async () => {
                const docRef = doc(db, "products", id);
                const docSnap = await getDoc(docRef);
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    setFormData({
                        ...data,
                        price: data.price.toString(),
                        images: data.images ? data.images.join("\n") : (data.image || ""),
                    } as any);
                }
            };
            fetchProduct();
        }
    }, [isEdit, id]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const productData = {
                ...formData,
                price: Number(formData.price),
                images: formData.images.split("\n").map(url => url.trim()).filter(url => url !== ""),
                updatedAt: new Date(),
            };

            if (isEdit && id) {
                await updateDoc(doc(db, "products", id), productData);
                toast.success("Product updated successfully");
            } else {
                await addDoc(collection(db, "products"), {
                    ...productData,
                    createdAt: new Date(),
                });
                toast.success("Product created successfully");
            }
            navigate("/admin");
        } catch (error) {
            console.error("Error saving product:", error);
            toast.error("Failed to save product");
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    return (
        <div className="min-h-screen bg-background">
            <Navbar />
            <div className="container mx-auto px-4 pt-24 pb-12 max-w-2xl">
                <h1 className="font-display text-3xl text-foreground mb-8">
                    {isEdit ? "Edit Product" : "Add New Product"}
                </h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-4 bg-card border border-border rounded-xl p-6">
                        <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Product Name</label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                                className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury"
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-foreground mb-2">Brand</label>
                                <input
                                    type="text"
                                    name="brand"
                                    value={formData.brand}
                                    onChange={handleChange}
                                    required
                                    className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-foreground mb-2">Price ($)</label>
                                <input
                                    type="number"
                                    name="price"
                                    value={formData.price}
                                    onChange={handleChange}
                                    required
                                    min="0"
                                    step="0.01"
                                    className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Category</label>
                            <select
                                name="category"
                                value={formData.category}
                                onChange={handleChange}
                                required
                                className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury"
                            >
                                <option value="">Select Category</option>
                                {categories.filter(c => c !== "All").map(c => (
                                    <option key={c} value={c}>{c}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Image URLs (one per line)</label>
                            <textarea
                                name="images"
                                value={formData.images}
                                onChange={handleChange}
                                required
                                rows={4}
                                placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg"
                                className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury resize-none"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Description</label>
                            <textarea
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                required
                                rows={4}
                                className="w-full px-4 py-2 bg-secondary border border-border rounded-lg text-foreground input-luxury resize-none"
                            />
                        </div>
                    </div>

                    <div className="flex justify-end gap-4">
                        <button
                            type="button"
                            onClick={() => navigate("/admin")}
                            className="px-6 py-2 border border-border text-foreground font-medium rounded-lg hover:bg-secondary transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={loading}
                            className="px-6 py-2 bg-primary text-primary-foreground font-semibold rounded-lg btn-gold"
                        >
                            {loading ? "Saving..." : "Save Product"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ProductForm;
